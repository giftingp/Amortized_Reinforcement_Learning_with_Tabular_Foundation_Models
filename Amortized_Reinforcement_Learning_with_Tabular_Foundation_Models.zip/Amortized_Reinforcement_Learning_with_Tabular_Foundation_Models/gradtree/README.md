# GradTree on Modal

Benchmarks GradTree (Marton et al., AAAI 2024) on the thesis protocol: 30
OpenML-CC18 datasets, five 50/50 stratified splits at seeds 42-46, depths 3, 4
and 5, reported as macro one-vs-rest AUC. 450 fits.

Needs no MotherNet checkpoint and no policy checkpoint. The numbers of
Amortized Reinforcement Learning with Tabular Foundation Models stay frozen in Table 4.1; this only adds rows.

## Run it

```bash
pip install modal
modal setup                     # once, opens a browser
modal run modal_gradtree.py
```

On Windows PowerShell, one command per line. PowerShell 5.1, the default on
Windows, has no `&&` separator, and Windows has no `unzip`:

```powershell
Expand-Archive gradtree_modal.zip -DestinationPath .
cd gradtree_modal
pip install modal
modal setup
modal run modal_gradtree.py
```

About 4 minutes of wall time and **about $0.12**, against the $30/month of free
credit on Modal's Starter plan.

## Closing the terminal

**Use this one if you want to walk away:**

```powershell
modal run --detach modal_gradtree.py::run_all
```

Safe to close the terminal as soon as it prints an app ID. Details below.


`modal run modal_gradtree.py` orchestrates the fan-out from your machine, so
closing the terminal stops the app. Adding `--detach` to it is **not** enough:
the Modal client warns that detached mode "only keeps the last triggered Modal
function alive after the parent process has been killed or disconnected," and
with the orchestration local there is no single function for it to keep.

So there is a second entrypoint whose fan-out happens inside a container:

```bash
modal run --detach modal_gradtree.py::run_all
```

```powershell
modal run --detach modal_gradtree.py::run_all
```

That is safe to disconnect from the moment it prints an app ID. `run_all`
spawns the shards from within Modal, merges them, and writes the result to the
volume. It takes the same `--depths` and `--shard-size` flags, and runs on a
quarter core while it waits, so the orchestrator itself costs a fraction of a
cent.

Afterwards, from any terminal:

```bash
modal app logs gradtree-benchmark              # check it finished, -f to follow
modal volume get gradtree-results gradtree_results.csv
```

Or rebuild the CSV from whatever shards completed, which also recovers a run
that died partway:

```bash
modal run modal_gradtree.py --collect
```

Shards are written to the volume as they finish, so no completed dataset is
ever lost, whichever way the run ends.

| Flag | Default | Effect |
|---|---|---|
| `--shard-size N` | 1 | datasets per container; 1 is fastest, 30 is one container |
| `--depths 3,4,5` | `3,4,5` | restrict depths, e.g. `--depths 3` |
| `--collect` | off | rebuild the CSV from the volume without recomputing |

Output is `gradtree_results.csv`, one row per fit, with `dataset, C, depth,
seed, auc, seconds, error`, plus a printed summary by depth and by
binary/multi-class split so it lines up with `tab:by-classes`.

If your laptop sleeps mid-run, the containers keep going and each writes its
shard to a Modal volume. Afterwards:

```bash
modal run modal_gradtree.py --collect
```

## Files

| File | Purpose |
|---|---|
| `modal_gradtree.py` | the Modal app: image, sharding, result collection |
| `benchmark_gradtree.py` | the benchmark, run inside each container |
| `tensorflow_addons_shim.py` | makes GradTree importable at all, see below |
| `cc_datasets_numpy.pkl` | the 30 datasets, torch-free (see below) |
| `convert_pickle_to_numpy.py` | regenerates that file from your original |

All of these must sit in the same directory; `modal_gradtree.py` checks and
exits with a clear message if one is missing. That check runs only locally:
Modal imports this module inside every container too, where the files live at
`/opt` instead, and an unconditional check fails all 30 containers at startup.

### Why the datasets were converted

`cc_test_datasets_multiclass_full.pkl` stores X and y as `torch.Tensor`, so
unpickling it imports torch. Nothing in this benchmark needs torch: the arrays
are read through `np.asarray` and the models are TensorFlow. Shipping an 800 MB
torch wheel in the image purely to deserialize two arrays per dataset would
slow every cold start for nothing, so the file is converted once to numpy.

The conversion is lossless, verified by rerunning the benchmark against both
files: kc2 at depth 3 gives 0.8206 either way.

If you ever need to regenerate it, anywhere torch is installed:

```bash
python convert_pickle_to_numpy.py cc_test_datasets_multiclass_full.pkl
```

Both scripts prefer `cc_datasets_numpy.pkl` and fall back to the original
filename if it is the only one present, in which case add `torch` to the image
or the run will fail with `No module named 'torch'`.

## Why the shim exists

GradTree as published does not install: it requires
`tensorflow-addons>=0.21.0`, which was archived in May 2024 and has no wheel
for any current Python. It does not need it. There are exactly three
`tensorflow-addons` call sites in `GradTree/GradTree.py`:

- `tfa.seq2seq.hardmax` is `tf.one_hot(tf.argmax(x, -1), ...)`
- `tfa.optimizers.SWA` is stochastic weight averaging, about 50 lines
- `tfa.metrics.RSquare` is regression only and never runs for classification

`entmax15` is defined by GradTree itself at `GradTree/GradTree.py:547`, not
imported from addons. So the shim is the whole dependency, and GradTree runs
unmodified on TensorFlow 2.21 under legacy Keras (`TF_USE_LEGACY_KERAS=1`,
since GradTree is Keras 2 code). No Python 3.10 environment and no old
TensorFlow.

## One bug, which is GradTree's

`GradTree.compile` appends the metric into the **caller's** list at
`GradTree/GradTree.py:225`: it calls `metrics.append(F1ScoreSparse(...))` where
`metrics_new.append(...)` was meant. Reuse one `metrics=["F1"]` list across
fits and the second fit inherits a built metric from the first model and dies
with `'F1Score' object has no attribute 'true_positives'`. Each fit works in
isolation, so in a benchmark loop it looks like nondeterminism.

`benchmark_gradtree.py` therefore builds fresh `cat_idx` and `metrics` lists
per fit (`fresh_args`). Worth a footnote if you report GradTree numbers, since
anyone reproducing them in a loop will hit it.

## Sizing, and why there is no GPU

Measured, not assumed. The training step is roughly 1M FLOPs and
dispatch-bound rather than FLOP-bound. mfeat-fourier, the largest dataset, at
depth 5:

| Threads | Fit time |
|---|---|
| 1 | 22.1 s |
| 2 | 24.6 s |
| 4 | 24.6 s |

So extra cores buy nothing and a GPU buys less. One core per container,
parallelism across datasets. Wall time falls with the shard count; cost does
not, because Modal bills core-seconds either way.

Measured fit times span 7.2 s (diabetes, depth 3) to 23.6 s (mfeat-fourier,
depth 5). At a conservative 15 s mean, 450 fits is 1.88 core-hours: $0.088 of
CPU at $0.0472/core-hour plus $0.030 of memory at $0.0080/GiB-hour for 2 GiB.

## Validation protocol

GradTree early-stops on a validation set. That set is carved out of the
**training** half (80/20, stratified), never from the test half: validating on
test would let it choose its stopping epoch using the data it is scored on. In
an earlier run of this benchmark it did exactly that, and the leak was worth
about **+0.041 AUC** on binary datasets, more than GradTree's entire apparent
margin over CART.

This matches GradTree's own example notebook, which splits train into
train/valid and fits CART on train+valid. So GradTree trains on 40% of each
dataset while CART and Amortized Reinforcement Learning with Tabular Foundation Models
train on 50%. That asymmetry is inherent to a
method that needs early stopping, and it runs against GradTree, so any win it
records is conservative. State it when you report the numbers.

## Default hyperparameters, deliberately

`benchmark_gradtree.py` uses the defaults from GradTree's own example notebook
(depth as given, learning rates 0.01, SWA, 1000 epochs, early stopping at 25,
batch 64). The paper's `GDTs-MULTI-HPO.ipynb` instead runs
`search_iterations: 300`, which would be 562 core-hours and about $36, over
the free credit.

It would also be the wrong comparison: CART and Amortized Reinforcement Learning with Tabular Foundation Models
both run at fixed
settings in your protocol, so 300 tuning trials for GradTree alone would stack
the comparison in its favor and invite exactly the objection you do not want
at a defense. If a reviewer asks for tuning, 20 trials costs about $2.40.

## Reproducibility

GradTree is pinned to commit `9b21272`, and TensorFlow and tf-keras to 2.21.0,
so a later upstream commit cannot silently change the numbers. Record the pin
in the thesis appendix alongside the baseline.

## You may not need Modal

450 fits at a 15 s mean is 1.9 core-hours. Six parallel processes on your
desktop finish in roughly 20 minutes for nothing, with the GPU idle either way.
Run `benchmark_gradtree.py` directly:

```bash
pip install tensorflow-cpu==2.21.0 tf-keras==2.21.0 category_encoders focal-loss
git clone https://github.com/s-marton/GradTree.git
cd GradTree && git checkout 9b212729cef7c9e246b2f933bece872c94c84c54 && cd ..
mkdir -p shim/tensorflow_addons
cp tensorflow_addons_shim.py shim/tensorflow_addons/__init__.py
TF_USE_LEGACY_KERAS=1 PYTHONPATH=shim:GradTree \
    python benchmark_gradtree.py --pickle cc_datasets_numpy.pkl
```

The same on Windows PowerShell. Note that `PYTHONPATH` is separated by a
semicolon on Windows, not a colon, which is the one thing here that fails
silently rather than loudly:

```powershell
pip install tensorflow-cpu==2.21.0 tf-keras==2.21.0 category_encoders focal-loss
git clone https://github.com/s-marton/GradTree.git
git -C GradTree checkout 9b212729cef7c9e246b2f933bece872c94c84c54
New-Item -ItemType Directory -Force -Path shim\tensorflow_addons | Out-Null
Copy-Item tensorflow_addons_shim.py shim\tensorflow_addons\__init__.py
$env:TF_USE_LEGACY_KERAS = "1"
$env:PYTHONPATH = "shim;GradTree"
python benchmark_gradtree.py --pickle cc_datasets_numpy.pkl
```

To shard across cores on Windows, pass `--only` a comma-separated subset per
process and merge the CSVs afterwards.

Modal buys a clean pinned environment and the ability to walk away, not speed.
