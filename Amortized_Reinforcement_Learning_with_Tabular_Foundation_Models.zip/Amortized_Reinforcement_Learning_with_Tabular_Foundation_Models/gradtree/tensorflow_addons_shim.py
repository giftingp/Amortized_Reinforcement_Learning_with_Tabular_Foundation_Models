"""Shim for the three tensorflow-addons call sites in GradTree/GradTree.py.
tensorflow-addons was archived in May 2024 and has no wheel for current Python,
so GradTree cannot be installed as published. These are the only three symbols
it uses:
  tfa.seq2seq.hardmax  -> one_hot(argmax), exactly equivalent
  tfa.optimizers.SWA   -> stochastic weight averaging around the inner optimizer
  tfa.metrics.RSquare  -> regression only; never reached for classification
"""
import sys
import types
import tensorflow as tf

seq2seq = types.ModuleType("tensorflow_addons.seq2seq")
optimizers = types.ModuleType("tensorflow_addons.optimizers")
metrics = types.ModuleType("tensorflow_addons.metrics")


def hardmax(x, name=None):
    return tf.one_hot(tf.argmax(x, -1), tf.shape(x)[-1], dtype=x.dtype)


class SWA:
    """Delegates to the wrapped optimizer and keeps a running average of the
    variables, refreshed every `average_period` steps. Not an Optimizer
    subclass: GradTree only ever calls apply_gradients, iterations and
    assign_average_vars on it, and staying out of the Keras optimizer
    hierarchy avoids its build/slot machinery entirely."""

    def __init__(self, optimizer, start_averaging=0, average_period=10,
                 name="SWA", **kw):
        self._opt = optimizer
        self.start_averaging = start_averaging
        self.average_period = max(int(average_period), 1)
        self._name = name
        self._avg, self._n = {}, None

    def __getattr__(self, item):
        return getattr(self._opt, item)

    def _ensure(self, varlist):
        if self._n is None:
            with tf.init_scope():
                self._n = tf.Variable(0.0, trainable=False, name="swa_n")
        for v in varlist:
            if v.ref() not in self._avg:
                with tf.init_scope():
                    self._avg[v.ref()] = tf.Variable(
                        tf.zeros_like(v), trainable=False, name="swa_avg")

    def apply_gradients(self, grads_and_vars, **kw):
        gv = list(grads_and_vars)
        varlist = [v for _, v in gv]
        self._ensure(varlist)
        out = self._opt.apply_gradients(gv, **kw)
        step = tf.cast(self._opt.iterations, tf.int64)
        due = tf.equal(tf.math.floormod(step, self.average_period), 0)

        def _acc():
            n = self._n + 1.0
            for v in varlist:
                a = self._avg[v.ref()]
                a.assign(a + (tf.cast(v, a.dtype) - a) / n)
            self._n.assign(n)
            return tf.constant(0)

        tf.cond(due, _acc, lambda: tf.constant(0))
        return out

    def assign_average_vars(self, var_list):
        def _do():
            for v in var_list:
                a = self._avg.get(v.ref())
                if a is not None:
                    v.assign(tf.cast(a, v.dtype))
            return tf.constant(0)

        if self._n is not None:
            tf.cond(self._n > 0, _do, lambda: tf.constant(0))

    def get_config(self):
        return {"name": self._name, "average_period": self.average_period}


class RSquare(tf.keras.metrics.Metric):
    def __init__(self, name="r_square", **kw):
        super().__init__(name=name, **kw)
        self._v = self.add_weight(name="v", initializer="zeros")

    def update_state(self, *a, **k):
        return None

    def result(self):
        return self._v


seq2seq.hardmax = hardmax
optimizers.SWA = SWA
metrics.RSquare = RSquare
sys.modules["tensorflow_addons.seq2seq"] = seq2seq
sys.modules["tensorflow_addons.optimizers"] = optimizers
sys.modules["tensorflow_addons.metrics"] = metrics
__version__ = "0.0.0-shim"
