"""
modal_gradtree.py
-----------------
Run the GradTree (Marton et al., AAAI 2024) benchmark on Modal, sharded one
container per dataset.

    pip install modal
    modal setup                       # once
    modal run modal_gradtree.py       # about 4 minutes, about $0.12

    modal run modal_gradtree.py --shard-size 3   # fewer, longer containers
    modal run modal_gradtree.py --depths 3       # one depth only
    modal run modal_gradtree.py --collect        # re-fetch results after a
                                                # dropped local connection

Sizing is measured rather than assumed. GradTree's training step is
dispatch-bound, not FLOP-bound: the largest of the 30 datasets at depth 5 takes
22.1 s on one thread and 24.6 s on four, so extra cores buy nothing and a GPU
buys less. One core per container, parallelism across datasets. Wall time falls
with the shard count; cost does not, because Modal bills core-seconds either
way.

Everything is pinned: the GradTree commit, TensorFlow, and tf-keras. GradTree
requires tensorflow-addons, archived in May 2024 with no wheel for current
Python; tensorflow_addons_shim.py supplies the three symbols it actually uses,
so no old Python or old TensorFlow is needed.
"""

import pathlib

import modal

# GradTree HEAD at the time of writing. Pinned so a later upstream commit
# cannot silently change the numbers in the thesis.
GRADTREE_COMMIT = "9b212729cef7c9e246b2f933bece872c94c84c54"

HERE = pathlib.Path(__file__).parent
# The original pickle stores X and y as torch.Tensor, so loading it imports
# torch, which the image does not have and does not need: the benchmark reads
# the arrays through np.asarray and fits TensorFlow models. Without this the
# containers die with "No module named 'torch'". convert_pickle_to_numpy.py
# produces the numpy version; the original is still accepted if it is all
# that is present, in which case torch must be added to the image.
DATA = HERE / "cc_datasets_numpy.pkl"
if not DATA.exists():
    DATA = HERE / "cc_test_datasets_multiclass_full.pkl"
SHIM = HERE / "tensorflow_addons_shim.py"
BENCH = HERE / "benchmark_gradtree.py"

# Local only. Modal imports this module inside every container to find
# the app, and there the three files are baked into /opt rather than sitting
# next to the script, so an unconditional check fails all 30 containers at
# startup with "missing cc_datasets_numpy.pkl".
if modal.is_local():
    for _p in (DATA, SHIM, BENCH):
        if not _p.exists():
            raise SystemExit(
                f"missing {_p.name} next to modal_gradtree.py.\n"
                "The directory needs all of: modal_gradtree.py, "
                "benchmark_gradtree.py, tensorflow_addons_shim.py, "
                "cc_datasets_numpy.pkl"
            )

image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("git")
    .pip_install(
        # Pinned: tensorflow-cpu and tf-keras must agree on major.minor, and
        # this pair is the one the benchmark was verified against.
        "tensorflow-cpu==2.21.0",
        "tf-keras==2.21.0",
        # Left to pip. GradTree only builds DataFrames and calls
        # category_encoders, so these are not version-sensitive, and resolving
        # them freely avoids pinning a combination that was never run.
        "category_encoders>=2.6",
        "focal-loss>=0.0.7",
        "scikit-learn>=1.3",
        "pandas>=2.0",
        "numpy>=1.26",
        "scipy",
    )
    .run_commands(
        "git clone https://github.com/s-marton/GradTree.git /opt/GradTree",
        f"cd /opt/GradTree && git checkout -q {GRADTREE_COMMIT}",
        "mkdir -p /opt/shim/tensorflow_addons",
    )
    .add_local_file(SHIM, "/opt/shim/tensorflow_addons/__init__.py", copy=True)
    .add_local_file(BENCH, "/opt/benchmark_gradtree.py", copy=True)
    .add_local_file(DATA, "/opt/data.pkl", copy=True)
    .env({
        "TF_USE_LEGACY_KERAS": "1",          # GradTree is Keras 2 code
        "PYTHONPATH": "/opt/shim:/opt/GradTree:/opt",
        "TF_CPP_MIN_LOG_LEVEL": "3",
        "TF_NUM_INTRAOP_THREADS": "1",
        "TF_NUM_INTEROP_THREADS": "1",
    })
)

app = modal.App("gradtree-benchmark", image=image)

# Shard results are also written here, so a dropped local connection does not
# throw away finished compute. `modal run modal_gradtree.py::collect` reads them.
results = modal.Volume.from_name("gradtree-results", create_if_missing=True)


@app.function(cpu=1.0, memory=2048, timeout=2 * 60 * 60,
              retries=modal.Retries(max_retries=1), volumes={"/results": results})
def run_shard(names: str, depths: str) -> str:
    """One container; one or more datasets, all seeds, the given depths."""
    import hashlib
    import subprocess

    tag = hashlib.sha1(f"{names}|{depths}".encode()).hexdigest()[:10]
    out = f"/results/shard_{tag}.csv"
    subprocess.run(
        ["python", "/opt/benchmark_gradtree.py",
         "--pickle", "/opt/data.pkl",
         "--depths", depths,
         "--only", names,
         "--threads", "1",
         "--out", out],
        check=True,
    )
    results.commit()
    return pathlib.Path(out).read_text()


def _shards(depths, shard_size, data_path):
    import pickle

    names = [e[0] for e in pickle.load(open(data_path, "rb"))]
    return names, [(",".join(names[i:i + shard_size]), depths)
                   for i in range(0, len(names), shard_size)]


def _merge(frames):
    """Concatenate shard CSVs into one, keeping a single header."""
    header, rows = None, []
    for text in frames:
        lines = [l for l in text.strip().splitlines() if l]
        if not lines:
            continue
        header = header or lines[0]
        rows += lines[1:]
    if not rows:
        return ""
    return header + "\n" + "\n".join(rows) + "\n"


# Fans out from INSIDE a container, so nothing depends on the local process.
# This is what `modal run --detach modal_gradtree.py::run_all` keeps alive:
# the client's own warning is that detached mode "only keeps the last triggered
# Modal function alive", and with the orchestration local there is no such
# single function to keep. Cheap and mostly idle while it waits on children.
@app.function(cpu=0.25, memory=512, timeout=6 * 60 * 60,
              volumes={"/results": results})
def run_all(depths: str = "3,4,5", shard_size: int = 1) -> str:
    names, shards = _shards(depths, shard_size, "/opt/data.pkl")
    print(f"{len(names)} datasets, depths {depths}, {len(shards)} shard(s)",
          flush=True)
    merged = _merge(run_shard.starmap(shards))
    pathlib.Path("/results/gradtree_results.csv").write_text(merged)
    results.commit()
    print(f"wrote /results/gradtree_results.csv "
          f"({len(merged.splitlines()) - 1} rows)", flush=True)
    return merged


def _write(frames, path="gradtree_results.csv"):
    merged = _merge(frames)
    if not merged:
        print("no rows returned")
        return
    pathlib.Path(path).write_text(merged)
    _report(path)


def _report(path="gradtree_results.csv"):
    import pandas as pd

    df = pd.read_csv(path)
    core_hours = df.seconds.sum() / 3600
    billed = core_hours * 0.0472 + core_hours * 2 * 0.0080
    print(f"\n{len(df)} fits, {core_hours:.2f} core-hours, "
          f"mean {df.seconds.mean():.1f}s per fit")
    print(f"billed about ${billed:.3f} "
          f"($0.0472/core-hour + $0.0080/GiB-hour x 2 GiB)")

    if "error" in df and df.error.notna().any():
        bad = df[df.error.notna() & (df.error.astype(str) != "")]
        if len(bad):
            print(f"  {len(bad)} failed fits: "
                  f"{bad.error.value_counts().to_dict()}")

    per = (df.dropna(subset=["auc"])
             .groupby(["dataset", "C", "depth"]).auc.mean().reset_index())
    print("\n  GradTree, macro one-vs-rest AUC:")
    for d in sorted(per.depth.unique()):
        g = per[per.depth == d]
        b, m = g[g.C == 2], g[g.C > 2]
        print(f"    depth {d}:  all {g.auc.mean():.4f} (n={len(g)})   "
              f"binary {b.auc.mean():.4f} (n={len(b)})   "
              f"multi-class {m.auc.mean():.4f} (n={len(m)})")
    print(f"\n  per-fit rows -> {path}")


def _collect_from_volume():
    """Rebuild the CSV from the volume, for when the local process died while
    containers were still running."""
    frames = []
    for entry in results.listdir("/"):
        name = entry.path.rsplit("/", 1)[-1]
        # shard_*.csv only: gradtree_results.csv is the merge of them, and
        # taking both would double every row.
        if name.startswith("shard_") and name.endswith(".csv"):
            frames.append(b"".join(results.read_file(entry.path)).decode())
    print(f"found {len(frames)} shard file(s) on the volume")
    return frames


# One entrypoint only. Modal refuses `modal run file.py` when a file defines
# several and none is named, so `collect` is a flag rather than a second one.
@app.local_entrypoint()
def main(shard_size: int = 1, depths: str = "3,4,5", collect: bool = False):
    if collect:
        _write(_collect_from_volume())
        return

    names, shards = _shards(depths, shard_size, DATA)
    print(f"{len(names)} datasets, depths {depths}, "
          f"{len(shards)} container(s) of {shard_size} dataset(s) each")
    print("\nThis streams from your machine and STOPS if you close the\n"
          "terminal. To walk away instead, interrupt this and run:\n"
          "    modal run --detach modal_gradtree.py::run_all\n")
    _write(run_shard.starmap(shards))
