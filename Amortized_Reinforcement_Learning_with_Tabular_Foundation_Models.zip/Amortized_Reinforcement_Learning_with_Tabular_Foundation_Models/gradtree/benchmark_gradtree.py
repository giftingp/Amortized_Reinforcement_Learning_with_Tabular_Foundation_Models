"""
benchmark_gradtree.py
---------------------
Benchmark GradTree (Marton et al., AAAI 2024) on the thesis's protocol:
30 CC-18 datasets, five 50/50 stratified splits at seeds 42-46, depths 3, 4, 5,
reported as macro one-vs-rest AUC and leaf count, so rows drop straight into
Table 4.1 beside the frozen numbers of Amortized Reinforcement Learning with Tabular Foundation Models.
Needs no encoder and no checkpoint.

GradTree as published will not install: it requires tensorflow-addons>=0.21.0,
which was archived in May 2024 and has no wheel for current Python. It does not
need it. There are exactly three tensorflow-addons call sites in
GradTree/GradTree.py, and `tensorflow_addons_shim.py` next to this file supplies
all three, so GradTree runs unmodified on current TensorFlow under legacy Keras.
No Python 3.10 environment and no old TensorFlow are required.

Setup:

    pip install tensorflow-cpu tf-keras category_encoders focal-loss
    git clone --depth 1 https://github.com/s-marton/GradTree.git

    # make the shim importable as `tensorflow_addons`
    mkdir -p shim/tensorflow_addons
    cp tensorflow_addons_shim.py shim/tensorflow_addons/__init__.py

    TF_USE_LEGACY_KERAS=1 PYTHONPATH=shim:GradTree \
        python benchmark_gradtree.py --pickle cc_datasets_numpy.pkl

A GPU does not help: the model is tiny and the step is dispatch-bound, so the
measured fit time is flat in thread count (22.1 s on one thread, 24.6 s on four
for the largest dataset at depth 5). Run it on one CPU core and parallelize
across datasets instead.
"""

import argparse
import os
import time
import warnings

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
warnings.filterwarnings("ignore")

import numpy as np
import pickle
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import label_binarize

SEEDS = (42, 43, 44, 45, 46)

PARAMS = {
    "learning_rate_index": 0.01, "learning_rate_values": 0.01,
    "learning_rate_leaf": 0.01, "optimizer": "SWA", "cosine_decay_steps": 0,
    "initializer": "RandomNormal", "loss": "crossentropy",
    "focal_loss": False, "temperature": 0.0, "from_logits": True,
    "apply_class_balancing": True,
}
ARGS = {
    "epochs": 1000, "early_stopping_epochs": 25, "batch_size": 64,
    "objective": "classification", "verbose": 0,
}


def fresh_args(seed):
    """`cat_idx` and `metrics` must be NEW lists on every fit.

    GradTree.compile has a bug at GradTree/GradTree.py:225: inside
    `for name in metrics:` it calls `metrics.append(F1ScoreSparse(...))`
    instead of appending to `metrics_new`, so it mutates the caller's list.
    Reuse one list across fits and the second fit inherits a built metric from
    the first model, which fails with
    `'F1Score' object has no attribute 'true_positives'`. This is why a loop
    over seeds breaks while each fit works in isolation."""
    return dict(ARGS, cat_idx=[], metrics=["F1"], random_seed=seed)


def auc(P, y, C):
    try:
        if C == 2:
            return roc_auc_score(y, P[:, 1] if P.ndim > 1 and P.shape[1] == 2
                                 else P.ravel())
        present = sorted(set(y.tolist()))
        if len(present) < 2:
            return np.nan
        return roc_auc_score(label_binarize(y, classes=present), P[:, present],
                             multi_class="ovr", average="macro")
    except (ValueError, IndexError):
        return np.nan


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pickle", default="cc_datasets_numpy.pkl")
    ap.add_argument("--depths", default="3,4,5")
    ap.add_argument("--only", default=None,
                    help="comma-separated dataset names, for sharding")
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--out", default="gradtree_results.csv")
    a = ap.parse_args()

    tf.config.threading.set_intra_op_parallelism_threads(a.threads)
    tf.config.threading.set_inter_op_parallelism_threads(a.threads)
    from GradTree import GradTree

    data = pickle.load(open(a.pickle, "rb"))
    if a.only:
        keep = set(a.only.split(","))
        data = [e for e in data if e[0] in keep]
    depths = [int(d) for d in a.depths.split(",")]

    rows, t_start = [], time.time()
    for e in data:
        name = e[0]
        X = np.nan_to_num(np.asarray(e[1], dtype=float))
        y = np.asarray(e[2], dtype=int)
        C = int(y.max()) + 1
        for depth in depths:
            for s in SEEDS:
                tr, te = train_test_split(np.arange(len(y)), test_size=0.5,
                                          random_state=s, stratify=y)
                # GradTree early-stops on its validation set, so that set must
                # come out of the TRAINING half. Passing the test half here
                # would let it select its stopping epoch on the test data and
                # inflate every score. This matches GradTree's own example
                # notebook, which carves a validation split off the training
                # data and gives CART train+validation, as the thesis does.
                try:
                    fit_idx, val_idx = train_test_split(
                        tr, test_size=0.2, random_state=s, stratify=y[tr])
                except ValueError:          # a class too rare to stratify
                    fit_idx, val_idx = train_test_split(
                        tr, test_size=0.2, random_state=s)
                params = dict(PARAMS, depth=depth)
                args = fresh_args(s)
                t0 = time.time()
                try:
                    m = GradTree(params, args)
                    m.fit(X[fit_idx], y[fit_idx],
                          X_val=X[val_idx], y_val=y[val_idx])
                    P = np.asarray(m.predict(X[te]))
                    score, fail = auc(P, y[te], C), ""
                except Exception as exc:                      # noqa: BLE001
                    score, fail = np.nan, type(exc).__name__
                    if os.environ.get("GT_TRACEBACK"):
                        import traceback
                        traceback.print_exc(limit=8)
                rows.append((name, C, depth, s, score, time.time() - t0, fail))
            done = [r for r in rows if r[0] == name and r[2] == depth]
            mean = np.nanmean([r[4] for r in done])
            secs = np.mean([r[5] for r in done])
            print(f"  {name:34s} C={C:2d} d={depth}  AUC {mean:.4f}  "
                  f"{secs:5.1f}s/fit", flush=True)

    import pandas as pd
    df = pd.DataFrame(rows, columns=["dataset", "C", "depth", "seed",
                                     "auc", "seconds", "error"])
    df.to_csv(a.out, index=False)
    per = (df.dropna(subset=["auc"])
             .groupby(["dataset", "C", "depth"]).auc.mean().reset_index())

    print(f"\n{len(df)} fits in {(time.time()-t_start)/60:.1f} min, "
          f"{df.seconds.sum()/3600:.2f} core-hours "
          f"(mean {df.seconds.mean():.1f}s per fit)")
    if df.error.ne("").any():
        print("  failures:", df[df.error != ""].error.value_counts().to_dict())
    print("\n  GradTree, macro one-vs-rest AUC:")
    for depth in depths:
        g = per[per.depth == depth]
        b, m = g[g.C == 2], g[g.C > 2]
        print(f"    depth {depth}:  all {g.auc.mean():.4f} (n={len(g)})   "
              f"binary {b.auc.mean():.4f} (n={len(b)})   "
              f"multi-class {m.auc.mean():.4f} (n={len(m)})")
    print(f"\n  per-fit rows -> {a.out}")


if __name__ == "__main__":
    main()
