"""
convert_pickle_to_numpy.py
--------------------------
cc_test_datasets_multiclass_full.pkl stores X and y as torch.Tensor, so
unpickling it imports torch. Nothing in the GradTree benchmark needs torch:
it reads the arrays through np.asarray and fits TensorFlow models. Carrying an
800 MB torch wheel in the Modal image purely to deserialize two arrays per
dataset would slow every cold start for no benefit.

This rewrites the file with the tensors as numpy arrays and everything else
untouched, producing cc_datasets_numpy.pkl. Run it once, anywhere torch is
installed; the output needs only numpy.

    python convert_pickle_to_numpy.py cc_test_datasets_multiclass_full.pkl

Both benchmark_gradtree.py and modal_gradtree.py default to the converted file
and fall back to the original name if it is the only one present.
"""

import pickle
import sys


def to_numpy(obj):
    """Recursively replace torch tensors with numpy arrays."""
    mod = type(obj).__module__
    if mod.split(".")[0] == "torch" and hasattr(obj, "detach"):
        return obj.detach().cpu().numpy()
    if isinstance(obj, dict):
        return {k: to_numpy(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [to_numpy(v) for v in obj]
    if isinstance(obj, tuple):
        return tuple(to_numpy(v) for v in obj)
    return obj


def find_torch(obj, path="root"):
    """Report anything left that would still import torch on load."""
    out = []
    if type(obj).__module__.split(".")[0] == "torch":
        out.append(f"{path}: {type(obj).__module__}.{type(obj).__name__}")
    elif isinstance(obj, dict):
        for k, v in obj.items():
            out += find_torch(v, f"{path}[{k!r}]")
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            out += find_torch(v, f"{path}[{i}]")
    return out


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "cc_test_datasets_multiclass_full.pkl"
    dst = sys.argv[2] if len(sys.argv) > 2 else "cc_datasets_numpy.pkl"

    data = to_numpy(pickle.load(open(src, "rb")))

    leftover = find_torch(data)
    if leftover:
        raise SystemExit("torch objects remain, conversion incomplete:\n  "
                         + "\n  ".join(leftover[:10]))

    with open(dst, "wb") as f:
        pickle.dump(data, f, protocol=4)

    print(f"{src} -> {dst}")
    print(f"  {len(data)} datasets, no torch objects remain")
    e = data[0]
    print(f"  example: {e[0]}, X {type(e[1]).__name__}{e[1].shape}, "
          f"y {type(e[2]).__name__}{e[2].shape}")


if __name__ == "__main__":
    main()
